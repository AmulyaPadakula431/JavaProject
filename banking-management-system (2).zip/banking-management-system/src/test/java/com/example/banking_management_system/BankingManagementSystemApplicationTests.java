package com.example.banking_management_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankingManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
