package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.Account;
import com.example.service.AccountService;

@RestController

public class AccountController {
	@Autowired
	private AccountService accountservice;
		
		

		@PostMapping("/api/addaccount")
		public ResponseEntity<Account> saveAccount(@RequestBody Account account)
		{
			//return employeeService.saveEmployee(employee);
			return new ResponseEntity<Account>(accountservice.saveAccount(account),
					HttpStatus.CREATED);
		}
		
		//build get all employee REST API
		@GetMapping("/api/getAllAccount")
	    public List<Account> getAllAccount()
	    {
		
	    	return accountservice.getAllAccounts();
	    }
		
		//build get employee by id REST API
		//http://localhost:8085/api/employees/2
		@GetMapping("/api/getAcctById/{id}")
		public ResponseEntity<Account> getAccountById(@PathVariable("id") long accountid)
		{
		return new ResponseEntity<Account> (accountservice.getAccountById(accountid),HttpStatus.OK);
			
		}
		
	//build update employee REST API
		//http://localhost:8085/api/employees/2	
	@PutMapping("/api/updateacctById/{id}")
	public ResponseEntity<Account>	updateAccount(@PathVariable("id") long id,
			@RequestBody Account account)

	{
		return new ResponseEntity<Account>(accountservice.updateAccount(account, id),
				HttpStatus.OK);
	}
		

	//build delete employee REST API
	//http://localhost:8085/api/employees/2	

	@DeleteMapping("/api/deleteAccountById/{id}")
	public ResponseEntity<String> deleteAccount(@PathVariable("id") long id)
	{
		
	accountservice.deleteAccount(id);
	return new ResponseEntity<String>("Account deleted successfully", HttpStatus.OK);
	}

	

}
