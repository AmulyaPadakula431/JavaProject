package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.Branch;
import com.example.service.BranchService;

@RestController
public class BranchController {
	@Autowired
    private BranchService branchService;

    @PostMapping("/api/addbranch")
    public ResponseEntity<Branch> saveBranch(@RequestBody Branch branch) {
        return new ResponseEntity<Branch>(branchService.saveBranch(branch), HttpStatus.CREATED);
    }

    @PostMapping("/api/assignment/{accountId}/{branchId}")
    public ResponseEntity<String> assignAccountToBranch(
            @PathVariable("accountId") long accountId,
            @PathVariable("branchId") int branchId) {
        return new ResponseEntity<String>(branchService.assignAccountToBranch(accountId, branchId), HttpStatus.CREATED);
    }

}
