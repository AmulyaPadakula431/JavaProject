package com.example.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "account")
public class Account {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long accountId;
    
    @Column(name = "account_holder_first_name")
    private String accountHolderFirstName;
    
    @Column(name = "account_holder_last_name")
    private String accountHolderLastName;
    
    @Column(name = "email")
    private String email;
    
    @Column(name = "balance")
    private double balance;
    
    @ManyToOne
    @JoinColumn(name = "branch_id")
    @JsonIgnoreProperties("accounts")
    private Branch branch;

	public Object getEmail() {
		// TODO Auto-generated method stub
		return null;
	}

	

}
