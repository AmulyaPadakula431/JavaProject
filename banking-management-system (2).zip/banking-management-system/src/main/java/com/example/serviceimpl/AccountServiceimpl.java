package com.example.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.entity.Account;
import com.example.repository.AccountRepository;
import com.example.service.AccountService;

public class AccountServiceimpl implements AccountService{
	@Autowired
	private AccountRepository accountrepository;

	@Override
	public Account saveAccount(Account account) {
		// TODO Auto-generated method stub
		return accountrepository.save(account);
	}

	@Override
	public List<Account> getAllAccounts() {
		// TODO Auto-generated method stub
		return accountrepository.findAll();
	}

	@Override
	public Account getAccountById(long id) {
		// TODO Auto-generated method stub
		return accountrepository.findById(id).get();
	}

	@Override
	public Account updateAccount(Account account, long id) {
		// TODO Auto-generated method stub
		Account existingcoust = accountrepository.findById(id).get();
		existingcoust.setAccountHolderFirstName(account.getAccountHolderFirstName());
		existingcoust.setAccountHolderLastName(account.getAccountHolderLastName());
		existingcoust.setEmail(account.getEmail());
		accountrepository.save(existingcoust);
		return existingcoust;
	}

	@Override
	public void deleteAccount(long id) {
		// TODO Auto-generated method stub
		accountrepository.deleteById(id);
	}

}
