package com.example.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.entity.Account;
import com.example.entity.Branch;
import com.example.repository.AccountRepository;
import com.example.repository.BranchRepository;
import com.example.service.BranchService;

public class BranchServiceImpl implements BranchService{
	@Autowired
	private BranchRepository branchrepository;
	private AccountRepository accountrepository;

	@Override
	public Branch saveBranch(Branch branch) {
		// TODO Auto-generated method stub
		return branchrepository.save(branch);
	}

	@Override
	public String assignAccountToBranch(long accountId, int branchId) {
		// TODO Auto-generated method stub
		Account account = accountrepository.findById(accountId).get();
		Branch branch = branchrepository.findById(branchId).get();
		List<Account> accountlist=new ArrayList<>();
		accountlist.add(account);
		branch.setAccounts(accountlist);
		account.setBranch(branch);
		accountrepository.save(account);
		
		return "finished!!";
	}

}
