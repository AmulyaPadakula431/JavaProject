package com.example.service;

import com.example.entity.Branch;

public interface BranchService {
	Branch saveBranch(Branch branch);
    String assignAccountToBranch(long accountId, int branchId);
    

}
